VaultSync - r/SideProject screenshot kit
Source: ATAC-Helicopter/VaultSync, Stable branch (real app screenshots).

UPLOAD IN THIS ORDER:
01_Dashboard.png - Dashboard overview and cover.
02_Backups.png - Project/folder backup workflows.
03_History.png - Timeline and restore points.
04_Recovery_Readiness.png - Readiness and protection gaps.
05_Recovery_Drill.png - Verified recovery-drill evidence.

ALTERNATIVE:
06_Snapshot_Compare_Alternative.png - Snapshot comparison.

These screenshots show the stable 1.8.9 app.
VaultSync 1.9 disk imaging and bootable recovery are not yet released.
Project: https://github.com/ATAC-Helicopter/VaultSync
Website: https://fglabs.dev/vaultsync
